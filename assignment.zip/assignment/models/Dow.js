var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var dowSchema = new Schema({
  quarter: String,
  stock:   String,
  date:    String,
  open:    String,
  high:    String,
  low:     String,
  close:   String,
  volume:  String,
  percent_change_price: String,
  percent_change_volume_over_last_wk: String,
  previous_weeks_volume: String,
  next_weeks_open: String,
  next_weeks_close: String,
  percent_change_next_weeks_price: String,
  days_to_next_dividend: String,
  percent_return_next_dividend: String
});
module.exports = mongoose.model('Dow', dowSchema);




     
