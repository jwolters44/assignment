# Import CSV Using NodeJS

Programmer Blog: https://programmerblog.net/

Source code for article on Import CSV file using nodejs and MongoDB

You can read detailed tutorial on our blog: http://programmerblog.net/import-csv-file-using-nodejs/

   
1. Create a MongoDB database

2. Generate an application, to import CSV file  using NodeJS

3. Install Mongoose module to connect and process data using mongoose application.

4. Install Fast-CSV module to import CSV file using nodejs into MongoDB collection

5. Install flash-connect module to display a success flash message

6. Ajax GET request to fetch and display data using Nodejs and MongoDB


Note: Run MongoDB and on command line type command: 
    
     use assignment
 
