//DECLARATIONS

var express = require('express');
var csv = require("fast-csv");
var router = express.Router();
var fs = require('fs');
var mongoose = require('mongoose');
var Dow  = mongoose.model('Dow');
var csvfile = __dirname + "/../public/files/dow_data.csv";
var stream = fs.createReadStream(csvfile);

//ROUTING

/* get home page. */
router.get('/', function(req, res, next) {

    res.render('index', { title: 'JFW RBC Assignment' });

// import csv
}).get('/import', function(req, res, next) {

    var dow  = []
    var csvStream = csv()
        .on("data", function(data){
         
         var item = new Dow({
              quarter: data[0],
              stock: data[1],
              date: data[2],
              open: data[3],
              high: data[4],
              low: data[5],
              close: data[6],
              volume: data[7],
              percent_change_price: data[8],
              percent_change_volume_over_last_wk: data[9],
              previous_weeks_volume: data[10],
              next_weeks_open: data[11],
              next_weeks_close: data[12],
              percent_change_next_weeks_price: data[13] ,
              days_to_next_dividend: data[14],
              percent_return_next_dividend: data[15]
         });
         
          item.save(function(error){
            console.log(item);
              if(error){
                   throw error;
              }
          }); 

    }).on("end", function(){

    });
  
    stream.pipe(csvStream);
    res.json({success : "Data imported successfully.", status : 200});

  // fetch data all 
  }).get('/fetchdata', function(req, res, next) {

    Dow.find({}, function(err, docs) {
        if (!err){ 
            res.json({success : "Returned Successfully", status : 200, data: docs});
        } else { 
            throw err;
        }
    });
    
  // get fetch stock data  
  }).get('/fetchstock', function(req, res, next) {

    Dow.find({'stock': 'AXP'}, function(err, docs) {
        if (!err){ 
            res.json({success : "Returned Successfully", status : 200, data: docs});
        } else { 
            throw err;
        };
    });

  // post insert data 
  }).post('/insert', function(req, res){

    var insertRow = new Dow({
        quarter: "4",
        stock: "JW",
        date: "01/01/2021",
        open: "15.00",
        high: "25.00",
        low: "13.00",
        close: "21.00",
        volume: "25000",
        percent_change_price: "5",
        percent_change_volume_over_last_wk: "2.5",
        previous_weeks_volume: "20000",
        next_weeks_open: "21.00",
        next_weeks_close: "23.00",
        percent_change_next_weeks_price: "1.5",
        days_to_next_dividend: "6",
        percent_return_next_dividend: "8"
        });
        insertRow.save(function(err){
            console.log(insert);
              if(err){
                   return handleError (err);
              }
        });
          
        res.json({success : "Data inserted successfully.", status : 200});

});
module.exports = router;


