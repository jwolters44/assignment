$(function(){

    //import data button call
    $("#importdata").on('click', function(){
        $.get( "/import", function( data ) {
            $("#message").show().html(data['success']);
        });
    });

    //fetch data button call
    $("#fetchdata").on('click', function(){
        $.get( "/fetchdata", function( data ) {
            var Dow = data['data'];
            $("#trdata").html('');
            $("#message").hide();
            var string = '';
            $.each(Dow, function(index, data ) {

                string += '<tr><td>'+(index+1)+
                          '</td><td>'+data['quarter']+
                          '</td><td>'+data['stock']+
                          '</td><td>'+data['date']+
                          '</td><td>'+data['open']+
                          '</td><td>'+data['high']+
                          '</td><td>'+data['low']+
                          '</td><td>'+data['close']+
                          '</td><td>'+data['volume']+
                          '</td><td>'+data['percent_change_price']+
                          '</td><td>'+data['percent_change_volume_over_last_wk']+
                          '</td><td>'+data['previous_weeks_volume']+
                          '</td><td>'+data['next_weeks_open']+
                          '</td><td>'+data['next_weeks_close']+
                          '</td><td>'+data['percent_change_next_weeks_price']+
                          '</td><td>'+data['days_to_next_dividend']+
                          '</td><td>'+data['percent_return_next_dividend']+
                          '</td></tr>';
                           });

            $("#trdata").html(string);
        });
    });

    //fetch stock button call
    $("#fetchstock").on('click', function(){
        $.get( "/fetchstock", function( data ) {
            var Dow = data['data'];
            $("#trdata").html('');
            $("#message").hide();
            var string = '';
            $.each(Dow, function(index, data ) {

                string += '<tr><td>'+(index+1)+
                          '</td><td>'+data['quarter']+
                          '</td><td>'+data['stock']+
                          '</td><td>'+data['date']+
                          '</td><td>'+data['open']+
                          '</td><td>'+data['high']+
                          '</td><td>'+data['low']+
                          '</td><td>'+data['close']+
                          '</td><td>'+data['volume']+
                          '</td><td>'+data['percent_change_price']+
                          '</td><td>'+data['percent_change_volume_over_last_wk']+
                          '</td><td>'+data['previous_weeks_volume']+
                          '</td><td>'+data['next_weeks_open']+
                          '</td><td>'+data['next_weeks_close']+
                          '</td><td>'+data['percent_change_next_weeks_price']+
                          '</td><td>'+data['days_to_next_dividend']+
                          '</td><td>'+data['percent_return_next_dividend']+
                          '</td></tr>';
                           });

            $("#trdata").html(string);
        });
    });

   //insert data button call
    $("#insertdata").on('click', function(){
        $.post( "/insertdata", function( data ) {
            $("#message").show().html(data['success']);
        });
    });

/*
    //clear data button call
    $("#cleardata").on('click', function(){
        $.get( "/clear", function( data ) {
            $("#message").show().html(data['success']);
        });
    });
*/
}); 

